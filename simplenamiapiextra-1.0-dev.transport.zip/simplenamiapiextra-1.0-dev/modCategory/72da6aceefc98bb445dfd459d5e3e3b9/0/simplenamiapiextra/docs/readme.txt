Extra: simpleNaMiAPIExtra
=========================

Ein Extra, das simpleNaMiAPI in MODX integriert. Mehr zu simpleNaMiAPI unter:
https://github.com/Florian1990/simpleNaMiAPI