<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Copyright (c) 2017 Florian Will

The Universal Permissive License (UPL), Version 1.0

Subject to the condition set forth below, permission is hereby granted to any
person obtaining a copy of this software, associated documentation and/or data
(collectively the “Software”), free of charge and under any and all copyright
rights in the Software, and any and all patent rights owned or freely licensable
by each licensor hereunder covering either (i) the unmodified Software as
contributed to or provided by such licensor, or (ii) the Larger Works (as
defined below), to deal in both

(a) the Software, and

(b) any piece of software and/or hardware listed in the lrgrwrks.txt file if one
    is included with the Software (each a “Larger Work” to which the Software is
    contributed by such licensors),

without restriction, including without limitation the rights to copy, create
derivative works of, display, perform, and distribute the Software and make,
use, sell, offer for sale, import, export, have made, and have sold the Software
and the Larger Work(s), and to sublicense the foregoing rights on either these
or other terms.

This license is subject to the following condition:

The above copyright notice and either this complete permission notice or at a
minimum a reference to the UPL must be included in all copies or substantial
portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.',
    'readme' => 'Extra: simpleNaMiAPIExtra
=========================

Ein Extra, das simpleNaMiAPI in MODX integriert. Mehr zu simpleNaMiAPI unter:
https://github.com/Florian1990/simpleNaMiAPI

Funktionsumfang
---------------

simpleNaMiAPIExtra stellt zwei Schnittstellen zur Verfügung:

1. Die Klasse modNamiWrapper
2. Das Snippet getNamiWrapper

Die Klasse modNamiWrapper erweiter NamiWrapper. Die Dokumentation zu NamiWrapper
ist an folgender Stelle zu finden:
https://github.com/Florian1990/simpleNaMiAPI#funktionsumfang

modNamiWrapper unterscheidet sich von NamiWrapper folgendermaßen:

* Alle Funktionen, die Exceptions werfen wurden überschrieben, um diese in MODX
  zu loggen.
* Der Konstruktor hat folgende Signatur:
  public function __construct($modx, $config = null)
  $modx erwartet dabei das modX-Objekt, $config ggf. einen Array, der an den
  Eltern-Konstruktor übergeben wird. (Mehr zu $config in der Dokumentation zu
  simpleNaMiAPI.)

getNamiWrapper ist dafür gedacht, ein modNamiWrapper-Ojekt bereitzustellen.
Dieses Snippet ruft $modx->getService() auf um ein Objekt der Klasse
modNamiWrapper bereitzustellen.

Folgende Parameter können an das Snippet übergeben werden:

&name string Optional. Standardwert: \'modNamiWrapper\'. Der Name, unter dem das
    erstellte Objekt für nachfolgend ausgeführte Snippets zur Verfügung steht.
&config array Optional. Standardwert: `[]`. Das Konfigurations-Array, das an
    den Konstruktor von modNamiWrapper übergeben wird.
&iniFile string|null Optional. Standardwert: null. Falls &iniFile ungleich null
    bzw. \'\' ist, wird $config[\'iniFile\'] auf den übergebenen Wert gesetzt.
    Relative Pfadangaben sind relativ zu
    {core_path}components/simplenamiapiextra/model/simplenamiapi/
&saveCookieInFile boolean|null Optional. Standardwert: null. Falls
    &saveCookieInFile ungleich null bzw. \'\' ist, wird
    $config[\'saveCookieInFile\'] auf den übergebenen Wert gesetzt.
&saveCookieInSession boolean Optional. Standardwert: false. Falls
    &saveCookieInSession true ist, wird der Inhalt des NaMi-Cookies in
    $_SESSION[\'simpleNaMiAPIExtra.\' . &name] gespeichert.

Beispiel 1: Snippet in Ressource einbinden

Wenn Sie in einer Ressource [[!getNamiWrapper? &name=`meinWrapper`]] einbinden,
können alle nachfolgend ausgefürhten Snippets mittels $nw =
$modx->getService(\'meinWrapper\') auf das erstellte Objekt zugreifen.

Beispiel 2: Snippet in Snippet etc. einbinden

Wesentlich komfortabler ist der Aufruf von getNamiWrapper direkt in einem
Snippet, Plugin etc.:

$nw = $modx->runSnippet(\'getNamiWrapper\', [\'saveCookieInFile\' => true]);
$nw2 = $modx->runSnippet(\'getNamiWrapper\', [\'name\' => \'meinNamiWrapper\',
    \'saveCookieInSession\' => true, \'iniFile\' => \'special.ini\']);

Werden verschiedene Instanzen von modNamiWrapper benötigt, ist darauf zu achten,
dass sie mit verschiedenen name-Parametern aufgerufen werden, da
$modx->getService() sonst beim zweiten Aufruf keine neue Instanz anfertigt,
sondern die erste zurückgibt.',
    'changelog' => 'Versionshistorie für simpleNaMiAPIExtra
=======================================

Version 1.0 rc1
---------------

* simpleNaMiAPI eingebunden.
* NamiWrapper-Klasse erweitert.
* getNamiWrapper-Snippet geschrieben.
* Standard-Optionen für getNamiWrapper-Snippet festgelegt.
* Installations-Optionen hinzugefügt.
* Resolver zur Erstellung einer custom.ini-Datei geschrieben.
* Hinweistext verfasst.

Version 1.0 dev
---------------

* Initiale Builds.',
    'setup-options' => 'simplenamiapiextra-1.0-rc1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7054b9ed336be40988543daf5e7d3f56',
      'native_key' => 1,
      'filename' => 'modCategory/d93653353dd452693e75fbab7f18a157.vehicle',
    ),
  ),
);